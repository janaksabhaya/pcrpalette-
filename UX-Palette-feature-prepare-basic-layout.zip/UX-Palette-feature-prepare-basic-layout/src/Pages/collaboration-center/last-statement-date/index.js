import React, { useContext } from 'react';
import PageHeader from '../../../Components/Common/PageHeader';

const LastStatementDate = () => {
  return (
    <>
      <PageHeader title="Last Statement Date" />
    </>
  );
};

export default LastStatementDate;
