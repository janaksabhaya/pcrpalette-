module.exports = {
  plugins: [require('autoprefixer')({ grid: true, overrideBrowsers: ['>1%'] })],
};
