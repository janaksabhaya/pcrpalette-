cp public/index.html.template public/index.html
cp azure_build_script.sh.template azure_build_script.sh
